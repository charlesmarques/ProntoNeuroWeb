<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 
 * author Bc05  "-_-" !! <odilon.garcez.moraes@gmail.com> 
 */

function get_post_action($name) {
    $params = func_get_args();

    foreach ($params as $name) {
        if (isset($_POST[$name]) || (isset($_GET[$name]))) {
            return $name;
        }
    }
}

//verifica o name enviado da p�gina de contato.html
switch (get_post_action('option')) :
    case 'option':
        if (isset($_POST['contact_name'])):
            $contactName = $_POST['contact_name'];
        endif;

        if (isset($_POST['contact_email'])):
            $contactEmail = $_POST['contact_email'];
        endif;

        if (isset($_POST['contact_subject'])):
            $titleMensageContact = $_POST['contact_subject'];
        endif;

        if (isset($_POST['contact_message'])):
            $contentMensageContact = $_POST['contact_message'];
        endif;

        require_once('../PHPMailer-master/class.phpmailer.php');
        require '../PHPMailer-master/class.smtp.php';

        $emailDestinatario = "prontoneuroemail@gmail.com"; //email que ir� receber as mensagens
        //$nomeEmailDestinatario = "Mensagem Pronto Neuro"; nome de quem ir� receber as mensagens
        $msghtml = "Nome cliente: " . $contactName . "<br>
                    E-mail Cliente: " . $contactEmail . "<br>
                    ----------------------------------------------<br>
                    Assunto: " . $contentMensageContact . "";

        // instancia a classe do PHPMailer para realizar o envio de e-mail
        $mail = new PHPMailer();
        $mail->SetLanguage('br');
        $mail->IsSMTP(); // Configura o objeto para usar SMTP
        //$mail->SMTPDebug = 2; // Debug do SMTP (para teste)
        // 1 = erros e mensagens
        // 2 = somente mensagens
        $mail->SMTPAuth = true; // ativa a autentica��o SMTP. O Gmail exige autentica��o, preciso disso
        $mail->SMTPSecure = "ssl"; // Configura o tipo de criptografia do SMTP do Gmail, no caso, SSL
        $mail->Host = "smtp.gmail.com"; // Configura servidor SMTP do Gmail
        $mail->Port = 465; // Configura porta do servidor SMTP do Gmail
        $mail->Username = "prontoneuroemail@gmail.com"; // Gmail remetente
        $mail->Password = "prontoneuroemail2016 "; // Senha remetente
        $mail->SetFrom($contactEmail); //remetente, nome do remetente
        $mail->Subject = 'Contato Pronto Neuro - ' . utf8_decode($titleMensageContact); // Assunto do e-mail
        $mail->AltBody = "Para visualizar a mensagem, por favor, use um cliente de e-mail compat�vel/configurado para ver mensagens HTML!"; // Mensagem alternativa caso o destinat�rio. Veja o e-mail em um aplicativo sem suporte ou n�o configurado para ver mensagens HTML
        $mail->MsgHTML($msghtml); // conte�do
        $mail->AddAddress($emailDestinatario, $nomeEmailDestinatario); // destinat�rio, nome
        if (!$mail->Send()) {
            echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert('E-mail n�o pode ser enviado. Tente novamente!')
                    window.location.href='http://prontoneuro.med.br/index.php/contato.html';
                </SCRIPT>");
        } else {

            echo ("<SCRIPT LANGUAGE='JavaScript'>
                    window.alert('E-mail enviado com sucesso!')
                    window.location.href='http://prontoneuro.med.br/index.php/contato.html';
                </SCRIPT>");
        }

        break;
endswitch;
